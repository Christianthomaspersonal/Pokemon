import java.awt.event.KeyListener;
import java.util.Random;
import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class ControllerModel implements KeyListener {
	
	Enemies[] enemies;
	Character mc  = new Character(50, 5, 4, 10, 10, 5);
	Enemies de;

	
	public ControllerModel() {
		
		
		//initialize list of enemy pokemon
		Random generator = new Random();
		int y = generator.nextInt(20);
		
		Pokemon[] enemypoke = new Pokemon[4];
		enemypoke[0] = new FirePokemon(10*y, 10*y, 10*y);
		enemypoke[1] = new GrassPokemon(5*y, 10*y, 15*y);
		enemypoke[2] = new WaterPokemon(15*y, 5*y, 15*y);
		enemypoke[3] = new RockPokemon(15*y, 10*y, 5*y);
		
		//establish number of enemies
		int x = generator.nextInt(6);
		enemies = new Enemies[x];
		
		for(int i = 0; i < x; i++) {
			//random number of pokemon and initializes each enemy
			int numberofpoke = generator.nextInt(3) + 1;
			int cx = generator.nextInt(20);
			int cy = generator.nextInt(20);
			
			enemies[i] = new Enemies(0, 0, numberofpoke, cx, cy, 0);
			//initializes enemy pokemon
			for(int v = 0; v < numberofpoke; v++) {
				enemies[i].setPokemon(enemypoke[v], v);
			}
				
		}
		
		//give character pokemon
		int v = generator.nextInt(40);
		
		FirePokemon fire = new FirePokemon(10*v, 10*v, 10*v);
		mc.setPokemon(fire, 0);
		
		WaterPokemon water = new WaterPokemon(10*v, 10*v, 10*v);
		mc.setPokemon(water, 1);
		
		GrassPokemon grass = new GrassPokemon(10*v, 10*v, 10*v);
		mc.setPokemon(grass, 2);
		
		RockPokemon rock = new RockPokemon(10*v, 10*v, 10*v);
		mc.setPokemon(rock, 3);
}
	
	public Enemies getE(int x) {
		return enemies[x];
	}
	
	public int getEAmount() {
		return enemies.length;
	}
	
	public int getECoorx(int i) {
		return enemies[i].getCurrentx();
	}
	
	public int getECoory(int i) {
		return enemies[i].getCurrenty();
	}
	
	public Pokemon getEPk(int x, int y) {
		return enemies[x].getPokemon(y);
	}
	
	//method to give enemy to battlepanel
	public Enemies getDE(int x, int y) {
		for(int i = 0; i < getEAmount(); i++) {
		if(getECoorx(i) == x && getECoory(i) == y ) {
			de = enemies[i];
			return getE(i);
		}
		}
		return null;
	}
	
	
	public Enemies returnDE() {
		return de;
	}
	
	public void erandomMotion() {
		for(int i = 0; i < enemies.length; i++){
			enemies[i].RandomMotion();
		}
	}
	
	public int getMCx() {
		return mc.getCurrentx();
	}
	
	public int getMCy()	{
		return mc.getCurrenty();
	}
	
	public void setMCx(int x) {
		mc.setCurrentx(x);
	}
	
	public void setMCy(int y)	{
		mc.setCurrenty(y);
	}
	
	public int getMCpb() {
		return mc.getPokeballs();
	}
	
	public int getMCm() {
		return mc.getMoney();
	}
	
	public Pokemon getMCpk(int x) {
		return mc.getPokemon(x);
		
	}
	
	public Character getMC() {
		return mc;
	}
	

	

	@Override
	public void keyPressed(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
		
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		System.out.println("Poop" + arg0.getKeyCode());
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		System.out.println("Poop" + arg0.getKeyCode());
	}
	
	
	
	
	
	

	

}
