import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.Timer;

public class Enemies extends Character {

	public Enemies(int m, int p, int pk, int x, int y, int pt) {
		super(m, p, pk, x, y, pt); 
	}
		
		// TODO Auto-generated constructor stub
		
	

	public void RandomMotion() {
		Random generator = new Random();
		int x = generator.nextInt(20);
		int y = generator.nextInt(20);
		if (x > 12 && getCurrentx() < 19) {
			setCurrentx(getCurrentx() + 1);
		} else if (x < 8 && getCurrentx() > 1) {
			setCurrentx(getCurrentx() -1);
		} if(y > 12 && getCurrenty() < 19) {
			setCurrenty(getCurrenty() + 1);
		} else if(y < 8 && getCurrenty() > 1) {
			setCurrenty(getCurrenty() - 1);
			
		}
		
	}

	
}
