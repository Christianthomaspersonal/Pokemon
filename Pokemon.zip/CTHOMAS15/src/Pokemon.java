
public abstract class Pokemon {
	
	protected int hp;
	protected int maxhp = 100;
	protected int strength;
	protected int defense;
	protected Types type;

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}
	

	public int getStrength() {
		return strength;
	}

	public void setStrength(int strength) {
		this.strength = strength;
	}

	public int getDefense() {
		return defense;
	}

	public void setDefense(int defense) {
		this.defense = defense;
	}

	public Types getType() {
		return type;
	}
	
	public void Attack1(Pokemon p) {
		
	}
	
	public void Attack2(Pokemon p) {
		
	}
	
	public void Tackle(Pokemon p) {
		
	}
	
}
