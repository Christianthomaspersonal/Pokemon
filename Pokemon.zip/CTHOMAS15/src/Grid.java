import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

public class Grid {
	
	type[][] grid = new type [20][20];
	enum type {dirt, tree, grass, hospital, store};
	
	public Grid() {
		
		Random generator = new Random();
		
		grid[10][10] = type.dirt;
		int current = 10;
		int kurrent = 10;
		
		//draw dirt path, everything not dirt, draw trees or grass
		int i = 50;
		int d = 2;
		while(i > 0) {
			int c = generator.nextInt(12);
			if (c > 0 && c < 3 && current != 1 && kurrent != 19) {
				grid[current-1][kurrent]= type.dirt;
				current = current - 1;
				
			} else if (c > 3 && c < 6 && current != 19 && kurrent != 19) {
				grid[current+1][kurrent]= type.dirt;
				current = current + 1;
			
			} else if (c > 6 && c < 9 && current != 19 && kurrent != 19) {
				grid[current][kurrent+1] = type.dirt;
				kurrent = kurrent + 1;
				
			} else if (c > 9 && c < 13 && current != 19 && kurrent != 1) {
				grid[current][kurrent-1]= type.dirt;
				
				kurrent = kurrent - 1;
			}
			i = i - 1;
		}
		for(int c = 0; c < 20; c++) {
			for(int k =0; k < 20; k++) {
				int prop = generator.nextInt(10);
				
				if (grid[c][k] != type.dirt) {
					if (prop < 5) {
					grid[c][k] = type.tree;
					} else {
						grid[c][k] = type.grass;
					}
				}
			}
		}
		
		
	}
	
	public void renderGround(int i, int c, Graphics g) {
		if (grid[i][c] == type.dirt) {
			g.setColor(Color.ORANGE);
			g.fillRect(i*20, c*20, 20, 20);
		} else if(grid[i][c] == type.grass) {
			g.setColor(Color.green);
			g.fillRect(i*20, c*20, 20, 20);
		} else if(grid[i][c] == type.tree) {
			g.setColor(Color.blue);
			g.fillRect(i*20, c*20, 20, 20);
		}
	}
		
	public void renderHospital(Graphics g) {
		int d = 1;
		for(int v = 0; v < 19 && d == 1; v++) {
			for(int b = 0; b < 19 && d ==1; b++) {
				if (grid[v][b] == type.hospital && d ==1) {
					grid[v][b] = type.hospital;
					g.setColor(Color.red);
					g.fillRect(v*20, b*20, 20, 20);
					d = 0;
				} else if(grid[v][b] == type.dirt && d == 1) {
					grid[v][b] = type.hospital;
					g.setColor(Color.red);
					g.fillRect(v*20, b*20, 20, 20);
					d = 0;
				} 
			}
		}
	}
	
	public void renderStore(Graphics g) {
		int d = 1;
		for(int v = 19; v > 0; v--) {
			for(int b = 19; b > 0; b--) {
				if (grid[v][b] == type.store && d ==1) {
					grid[v][b] = type.store;
					g.setColor(Color.black);
					g.fillRect(v*20, b*20, 20, 20);
					d = 0;
				} else if(grid[v][b] == type.dirt && d == 1) {
					grid[v][b] = type.store;
					g.setColor(Color.black);
					g.fillRect(v*20, b*20, 20, 20);
					d = 0;
				} 
			
			}
		}
	}
	
	//to pass grid type
	public type returnGround(int x, int y) {
		return grid[x][y];
	}
		
	

}
