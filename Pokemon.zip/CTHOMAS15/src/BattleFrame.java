import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.Timer;

public class BattleFrame extends JFrame implements ActionListener  {
	
	int control = 0;
	Timer t;
	Timer time = new Timer(100, this);
	Enemies enemy;
	Character main;

	public BattleFrame(Timer ot, Enemies e, Character mc) {
		t = ot;
		t.stop();
		
		time.addActionListener(this);
		
		e = enemy;
		mc = main;
		
		
		
		
	}
	
	public int getcontrol() {
		return control;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		if(enemy.allDead() == true) {
			t.start();
			control = 1;
		} else if(main.allDead() == true) {
			t.start();
			control = 2;
		}
		
	}

}
