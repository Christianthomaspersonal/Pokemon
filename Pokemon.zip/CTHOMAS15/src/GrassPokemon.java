
public class GrassPokemon extends Pokemon {
	
	protected int hp;
	protected int maxhp = 100;
	protected int strength;
	protected int defense;
	protected Types type = Types.Grass;
	
	public GrassPokemon(int h, int s, int d) {
		hp = h;
		strength = s;
		defense = d;
	}

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}
	
	public Types getType() {
		return type;
	}

	public int getStrength() {
		return strength;
	}

	public void setStrength(int strength) {
		this.strength = strength;
	}

	public int getDefense() {
		return defense;
	}

	public void setDefense(int defense) {
		this.defense = defense;
	}
	
	public void Tackle(Pokemon p2) {
		int damage;
		if(p2.getDefense() == 1) {
			damage = strength/2;
			} else {
				damage = strength;
			} p2.setHp(p2.getHp()-damage);
	}
	
	public void Attack1(Pokemon p2) {
		int damage;
		//attack against weak type
		if (p2.getType() == Types.Water) {
			if(p2.getDefense() == 1) {
			damage = strength*2;
			} else {
				damage = strength * 4;
			} p2.setHp(p2.getHp()-damage);
		}
		//attack against strong
		else if(p2.getType() == Types.Fire) {
			if(p2.getDefense() == 1) {
				damage = strength/8;
				} else {
					damage = strength/4;
				} p2.setHp(p2.getHp()-damage);
		} 
		//normal attack
		else {
			damage = strength/2;
			p2.setHp(p2.getHp()-damage);
		}
		
	}

	public void Attack2(Pokemon p2) {
		int damage;
		//weak type
		if (p2.getType() == Types.Water) {
			if(p2.getDefense() == 1) {
				damage = strength*4;
				} else {
					damage = strength * 8;
				} p2.setHp(p2.getHp()-damage);
		} 
		//strong type
		else if(p2.getType() == Types.Fire) {
			if(p2.getDefense() == 1) {
				damage = strength/16;
				} else {
					damage = strength/8;
				} p2.setHp(p2.getHp()-damage);
		} 
		//normal attack
		else {
			damage = strength-5;
			p2.setHp(p2.getHp()-damage);
		}
		
	}
	
}



