import java.awt.BorderLayout;

import java.awt.Color;
import java.awt.Desktop.Action;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.Timer;

public class Main {
	


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		//get a frame
		JFrame frame = new JFrame("Big Frame");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		//add some mf panels
		GamePanel panel = new GamePanel();
		panel.setPreferredSize(new Dimension(800,600));
		panel.setBackground(Color.white);
		
		InfoPanel infopanel = new InfoPanel(panel);
		infopanel.setPreferredSize(new Dimension(150, 200));
		infopanel.setBackground(Color.orange);
		
		panel.addInfo(infopanel);
		
		frame.getContentPane().add(infopanel, BorderLayout.EAST);
		
		frame.pack(); 
		frame.setVisible(true);


		
		frame.addKeyListener(panel);
		frame.addKeyListener(infopanel);
		

		frame.getContentPane().add(panel, BorderLayout.CENTER);
		frame.pack(); 
		frame.setVisible(true);
		
	
		

			
	}
	
	
				
			
			
		
		
		
	}

	


