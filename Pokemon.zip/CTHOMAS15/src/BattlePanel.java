import java.util.Random;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class BattlePanel extends JPanel {
	
	
	ControllerModel c;
	Pokemon currentPokemon;
	JLabel currentpk;
	JLabel pkhealth;
	
	public BattlePanel(ControllerModel cm, int v) {
		
		c = cm;
		if (v == 1) {
			currentPokemon = c.getMC().getDangerousPokemon();
		} else {
		currentPokemon = c.getDE(c.getMCx(), c.getMCy()).getDangerousPokemon();
		}
		
		if (v == 1) {
		currentpk = new JLabel("Current Pokemon: " + c.getMC().getDangerousPokemon());
		pkhealth = new JLabel("Current Pokemon Health: " + c.getMC().getDangerousPokemon().getHp());
		add(currentpk);
		add(pkhealth);
		} else {
			currentpk = new JLabel("Current Pokemon: " + currentPokemon);
			//sometimes throws error on line twenty two, getDE and getDangerousPokemon work in other iterations, something about interplay
			pkhealth = new JLabel("Current Pokemon Health: " + c.getDE(c.getMCx(), c.getMCy()).getDangerousPokemon().getHp());
			add(currentpk);
			add(pkhealth);
			
		}
		
	}
	
	public void setPokemon(Pokemon x) {
		currentPokemon = x;
	}
	
	public Pokemon getPokemon() {
		return currentPokemon;
	}
	
	public ControllerModel getControllerModel() {
		return c;
	}
	
	public void updateLabels() {
		currentpk.setText("Current Pokemon" + currentPokemon);
		pkhealth.setText("Pokemon Health" + currentPokemon.getHp());
		
	}

	
}
