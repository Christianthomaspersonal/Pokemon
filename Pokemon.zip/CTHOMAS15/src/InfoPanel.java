import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class InfoPanel extends JPanel implements KeyListener {
	
	GamePanel g;
	ControllerModel c;
	Grid grid;
	int storemonitor;
	
	JLabel place;
	JLabel pokeballs;
	JLabel money;
	JLabel pokemon;
	JLabel potions;
	JLabel buypotions;
	JLabel buypokeballs;
	
	public InfoPanel(GamePanel game) {
		g = game;
		c = g.returnController();
		grid = g.returnGrid();
		pokeballs = new JLabel("Pokeballs: " + c.getMCpb() );
		money = new JLabel("money" + c.getMCm());
		place = new JLabel("Place:" + grid.returnGround(c.getMCx(), c.getMCy()));
		potions = new JLabel("Potions:" + c.getMC().getPotions());
		buypotions = new JLabel("");
		buypokeballs = new JLabel("");
		
		add(pokeballs);
		add(money);
		add(place);
		add(potions);
		add(buypotions);
		add(buypokeballs);
		addKeyListener(this);
		
		
	}
	
	public void updateLabels() {
		pokeballs.setText("Pokeballs: " + c.getMCpb() );
		money.setText("money" + c.getMCm());
		place.setText("Place:" + grid.returnGround(c.getMCx(), c.getMCy()));
		potions.setText("Potions" + c.getMC().getPotions());
	}
	
	public void controlstore(int g) {
		if(g == 1) {
			buypotions.setText("");
			buypokeballs.setText("");;
			} else if (g == 2) {
				buypotions.setText("Buy Potions Press A");
				buypokeballs.setText("Buy Pokeballs Press B");
			}
		
	}
	
	public int getcontrolstore() {
		return storemonitor;
	}

	
	

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
		if(e.getKeyCode() == KeyEvent.VK_A && c.getMC().getMoney() > 0) {
			c.getMC().setPotions(c.getMC().getPotions() + 1);
			c.getMC().setMoney(c.getMC().getMoney() - 20);
		}	else if(e.getKeyCode() == KeyEvent.VK_B && c.getMC().getMoney() > 0) {
			c.getMC().setPokeballs(c.getMC().getPokeballs() + 1);
			c.getMC().setMoney(c.getMC().getMoney() - 210);
		}
		
		
	}

}
