import java.util.Random;

public class Character {
	
	public int money;
	public int pokeballs;
	public Pokemon[] pokemon;
	private int currentx;
	private int currenty;
	public int potions;
	
	public Character(int m, int p, int pk, int x, int y, int pt) {
		money = m;
		pokeballs = p;
		pokemon = new Pokemon [pk];
		potions = pt;
		currentx = x;
		currenty = y;
		
	}

	public int getMoney() {
		return money;
	}

	public void setMoney(int money) {
		this.money = money;
	}

	public int getPokeballs() {
		return pokeballs;
	}

	public void setPokeballs(int pokeballs) {
		this.pokeballs = pokeballs;
	}

	public Pokemon getPokemon(int x) {
		return pokemon[x];
	}
	
	//method to give battlepanel current healthiest pokemon
	public Pokemon getDangerousPokemon() {
		Pokemon cpk = null;
		for(int i = 0; i < pokemon.length; i++) {
			cpk = pokemon[0];
			if(pokemon[0].getHp() < pokemon[i].getHp()) {
				cpk = pokemon[i];
			}
		}
		return cpk;
	}

	public void setPokemonAmount(int pk) {
		pokemon = new Pokemon [pk];
	}
	
	public int getPokemonAmount() {
		return pokemon.length;
	}
	
	public Pokemon setPokemon(Pokemon pk, int x) {
		pokemon[x] = pk;
		return pokemon[x];
	}
	
	public int getPotions() {
		return potions;
	}

	public void setPotions(int x) {
		potions = x;
	}
	
	public int getCurrentx() {
		return currentx;
	}
	
	public void setCurrentx(int x) {
		currentx = x;
		
	}
	
	public void setCurrenty(int y) {
		currenty = y;
		
	}


	public int getCurrenty() {
		return currenty;
	}

	public void setCoordinates(int x, int y) {
		currenty = y;
		currentx = x;
	}
	
	public boolean allDead() {
		int v = 0;
		for(int i = 0; i < pokemon.length; i++) {
			if(pokemon[i].getHp() <= 0) {
				v = v + 1;
			}
		}
		if(v == pokemon.length) {
			return true;
		} else {
			return false;
		}
	}
	
	


}
