
public enum Types {
	Fire, Water, Rock, Grass;

}
