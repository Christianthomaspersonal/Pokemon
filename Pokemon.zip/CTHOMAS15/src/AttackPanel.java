import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class AttackPanel extends JPanel implements ActionListener {
	
	ControllerModel c;
	BattlePanel bp1;
	BattlePanel bp2;
	JButton tackle;
	JButton attack1;
	JButton attack2;
	JButton switchpokemon;
	JButton potion;
	
	public AttackPanel(ControllerModel cm, BattlePanel b1, BattlePanel b2) {
		c = cm;
		bp1 = b1;
		bp2 = b2;
		
		tackle = new JButton("tackle");
		tackle.addActionListener(this);
		add(tackle);
		
		attack1 = new JButton("attack1");
		attack1.addActionListener(this);
		add(attack1);
		
		attack2 = new JButton("attack2");
		attack2.addActionListener(this);
		add(attack2);
		
		switchpokemon = new JButton("switch pokemon");
		switchpokemon.addActionListener(this);
		add(switchpokemon);
		
		potion = new JButton("potion");
		potion.addActionListener(this);
		add(potion);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == tackle) {
			bp1.getPokemon().Tackle(bp2.getPokemon());
		} else if(e.getSource() == attack1) {
			bp1.getPokemon().Attack1(bp2.getPokemon());
		} else if(e.getSource() == attack2) {
			bp1.getPokemon().Attack2(bp2.getPokemon());
		} else if(e.getSource() == switchpokemon) {
			Random gen = new Random();
			int x = gen.nextInt(3);
			bp1.setPokemon(c.getMCpk(x));
		} else if(e.getSource() == potion && bp1.getControllerModel().getMC().getPokeballs() > 0) {
			bp1.getPokemon().setHp(bp1.getPokemon().getHp() + 100);
			bp1.getControllerModel().getMC().setPokeballs(bp1.getControllerModel().getMC().getPokeballs() - 1);
		}
		Random y = new Random();
		int z = y.nextInt(2);
		if(z == 0) {
			bp2.getPokemon().Tackle(bp1.getPokemon());
		} else if(z == 1) {
			bp2.getPokemon().Attack1(bp1.getPokemon());
		} else if(z == 2) {
			bp2.getPokemon().Attack2(bp1.getPokemon());
		}
		
		if(bp2.getPokemon().getHp() <= 0) {
			bp2.setPokemon(bp2.getControllerModel().returnDE().getDangerousPokemon());
		} 
		
		if(bp1.getPokemon().getHp() <= 0) {
			bp1.setPokemon(bp1.getControllerModel().getMC().getDangerousPokemon());
		} 
		
		bp1.updateLabels();
		bp2.updateLabels();
		
	}

}
