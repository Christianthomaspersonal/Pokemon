import java.awt.Graphics;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

import javax.swing.Timer;

import java.awt.event.ActionEvent;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class GamePanel extends JPanel implements ActionListener, KeyListener {

	Grid grid = new Grid();
	ControllerModel c = new ControllerModel();
	InfoPanel info;
	Timer time = new Timer(2000, (ActionListener) this);
	


	//setup graphics object
	public void paintComponent(Graphics g) {
		super.paintComponent(g);


		time.start();

		// renders grid then hospital and store

		for(int a = 0; a < 20; a++) {
			for(int b = 0; b < 20; b++) {
				grid.renderGround(a, b, g);
			}
		}
		grid.renderHospital(g);
		grid.renderStore(g);


		//insert loop to draw all enemy circles here
		for(int i = 0; i < c.getEAmount(); i++) {
			g.setColor(Color.pink);
			g.drawOval(c.getECoorx(i)*20, c.getECoory(i)*20, 20, 20);
			g.fillOval(c.getECoorx(i)*20, c.getECoory(i)*20, 20, 20);
		}

		g.setColor(Color.cyan);
		g.fillOval(c.getMCx()*20, c.getMCy()*20, 20, 20);

		System.out.println(c.getMCx());
	}


	public void actionPerformed(ActionEvent arg0) {
		info.updateLabels();
		this.repaint();
		c.erandomMotion();
	
		if(grid.returnGround(c.getMCx(), c.getMCy()) == Grid.type.store){
				info.controlstore(2);
		} else if(grid.returnGround(c.getMCx(), c.getMCy()) != Grid.type.store) {
			info.controlstore(1);
		}
		if(grid.returnGround(c.getMCx(), c.getMCy()) == Grid.type.hospital){
			int i=0;
			do{
				c.mc.getPokemon(i).setHp(100);
				System.out.println("Healed Pokemon "+i);
				i++;
			}while(i != c.mc.getPokemonAmount());
		}

		for(int v = 0; v < c.getEAmount(); v++){
			if(c.getE(v).getCurrentx() == c.getMCx() && c.getE(v).getCurrenty() == c.getMCy()){
				time.stop();
				System.out.println("Making frame number "+v);
				BattleFrame battleframe = new BattleFrame(time, c.getE(v), c.getMC());
				battleframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

				BattlePanel charp = new BattlePanel(c, 1);
				charp.setPreferredSize(new Dimension(200, 400));
				charp.setBackground(Color.gray);
				BattlePanel battlep = new BattlePanel(c, 2);
				battlep.setBackground(Color.green);
				battlep.setPreferredSize(new Dimension(200, 400));
				AttackPanel attack = new AttackPanel(c, charp, battlep);
				attack.setPreferredSize(new Dimension(200, 200));
				attack.setBackground(Color.cyan);

				battleframe.getContentPane().add(charp, BorderLayout.EAST);
				battleframe.getContentPane().add(battlep, BorderLayout.WEST);
				battleframe.getContentPane().add(attack, BorderLayout.SOUTH);
				battleframe.pack(); 
				battleframe.setVisible(true);
				
				if(battleframe.getcontrol() == 1) {
					battleframe.dispose();
					c.getMC().setMoney(c.getMC().getMoney() + 100);	
				} else if(battleframe.getcontrol() == 2) {
					battleframe.dispose();
					
				}
				
			}
		}

	}


	//to pass the controller/model
	public ControllerModel returnController() {
		return c;
	}

	//to pass the grid
	public Grid returnGrid() {
		return grid;
	}


	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub

		if(e.getKeyCode() == KeyEvent.VK_UP) {
			c.setMCy(c.getMCy()-1);
		} else if(e.getKeyCode() == KeyEvent.VK_DOWN) {
			c.setMCy(c.getMCy()+1);
		} else if(e.getKeyCode() == KeyEvent.VK_RIGHT) {
			c.setMCx(c.getMCx()+1);
		} else if(e.getKeyCode() == KeyEvent.VK_LEFT) {
			c.setMCx(c.getMCx()-1);
		}

		System.out.println("Poop" + e.getKeyCode());


	}


	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub

	}


	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}


	public void addInfo(InfoPanel infopanel) {
		info = infopanel;

	}


}
